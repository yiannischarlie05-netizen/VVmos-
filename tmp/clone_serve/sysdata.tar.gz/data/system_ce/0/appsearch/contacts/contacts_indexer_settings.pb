<bundle>
<long name="last_delta_update_timestamp_millis" value="0" />
<long name="last_delta_delete_timestamp_millis" value="0" />
</bundle>
